### Commands

0. mann / --help
1. ls
2. pwd
3. whoami
4. grep
5. bash syntax : echo, for, do..done
6. cd
7. File
8. mkdir, rmdir, rm
9. touch
10. gedit
11. mv
12. cp
13. cat
14. ps --> Shell type
15. chmod
16. fcrackzip
17. stegseek
18. sudo / pip
19. strings
20. exiftool
